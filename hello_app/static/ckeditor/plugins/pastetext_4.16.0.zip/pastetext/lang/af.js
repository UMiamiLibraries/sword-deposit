/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'af', {
	button: 'Voeg by as eenvoudige teks',
	pasteNotification: 'Druk %1 om by te voeg. Jou leser ondersteun nie byvoeg deur die toolbar knoppie of die konteks kieslys nie',
	title: 'Voeg by as eenvoudige teks'
} );

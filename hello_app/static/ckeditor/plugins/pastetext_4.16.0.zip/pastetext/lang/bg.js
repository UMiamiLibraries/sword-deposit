/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'bg', {
	button: 'Вмъкни като чист текст',
	pasteNotification: 'Натиснете %1 за да поставите. Вашият браузър не поддържа поставяне с бутон от лентата с инструменти или контекстното меню.',
	title: 'Вмъкни като чист текст'
} );

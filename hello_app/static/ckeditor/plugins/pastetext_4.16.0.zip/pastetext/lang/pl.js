/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'pl', {
	button: 'Wklej jako czysty tekst',
	pasteNotification: 'Naciśnij %1 by wkleić tekst. Twoja przeglądarka nie obsługuje wklejania za pomocą przycisku paska narzędzi lub opcji menu kontekstowego.',
	title: 'Wklej jako czysty tekst'
} );

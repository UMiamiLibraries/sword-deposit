/*
Korean translation by Maxime Houdais
*/
CKEDITOR.plugins.setLang('wordcount', 'ko', {
    WordCount: '단어:',
    WordCountRemaining: '남은 단어',
    CharCount: '글자:',
    CharCountRemaining: '자 남음',
    CharCountWithHTML: '글자 와 HTML:',
    CharCountWithHTMLRemaining: '남은 글자 와 HTML',
    Paragraphs: '단락:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: '허용 된 한도를 초과하여 콘텐츠를 붙여 넣을 수 없습니다.',
    Selected: '선택:',
    title: '통계'
});
